package com.aaa.entity;

public class Caigou {
    private Integer caigouid ;
    private String caigouname ;
    private String gonghuoshang ;
    private String danwei ;
    private String  candi ;
    private String  leixing ;
    private Integer shuliang ;

    public Integer getCaigouid() {
        return caigouid;
    }

    public void setCaigouid(Integer caigouid) {
        this.caigouid = caigouid;
    }

    public String getCaigouname() {
        return caigouname;
    }

    public void setCaigouname(String caigouname) {
        this.caigouname = caigouname;
    }

    public String getGonghuoshang() {
        return gonghuoshang;
    }

    public void setGonghuoshang(String gonghuoshang) {
        this.gonghuoshang = gonghuoshang;
    }

    public String getDanwei() {
        return danwei;
    }

    public void setDanwei(String danwei) {
        this.danwei = danwei;
    }

    public String getCandi() {
        return candi;
    }

    public void setCandi(String candi) {
        this.candi = candi;
    }

    public String getLeixing() {
        return leixing;
    }

    public void setLeixing(String leixing) {
        this.leixing = leixing;
    }

    public Integer getShuliang() {
        return shuliang;
    }

    public void setShuliang(Integer shuliang) {
        this.shuliang = shuliang;
    }
}
