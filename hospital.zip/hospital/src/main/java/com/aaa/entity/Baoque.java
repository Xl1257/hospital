package com.aaa.entity;

public class Baoque {
    private Integer baoqueid;
    private String baoqueName;
    private Integer baoqueNum;

    public Integer getBaoqueid() {
        return baoqueid;
    }

    public void setBaoqueid(Integer baoqueid) {
        this.baoqueid = baoqueid;
    }

    public String getBaoqueName() {
        return baoqueName;
    }

    public void setBaoqueName(String baoqueName) {
        this.baoqueName = baoqueName;
    }

    public Integer getBaoqueNum() {
        return baoqueNum;
    }

    public void setBaoqueNum(Integer baoqueNum) {
        this.baoqueNum = baoqueNum;
    }
}
